var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

var Schema = mongoose.Schema;

var userSchema = new Schema(
	{
		username: {
			type: String,
		},
		password: {
			type: String
        },
        role: {
            type: String,
            default: "Student"
        },
        student_id: {
            type: String,
            required: [true, "student id is required"]
        },
        student_name: {
            type: String,
            default: ""
        },
        student_year: {
            type: String,
            default: ""
        },
        course_id: {
            type: String,
            default: ""
        },
        course_name: {
            type: String,
            default: ""
        },
        semester: {
            type: String,
            default: ""
        },
        assignment_name: {
            type: String,
            default: ""
        },
        assignment_desc: {
            type: String,
            default: ""
        },
        assignment_percentage: {
            type: String,
            default: ""
        },
        technology_use: {
            type: String,
            default: ""
        },
        scope: {
            type: String,
            default: ""
        },
        description: {
            type: String,
            default: ""
        },
        link_to_industry: {
            type: String,
            default: ""
        },
        application: {
            type: String,
            default: ""
        },
        photo: {
            type: String,
            default: ""
        }
	}
);

userSchema.methods.comparePassword = function(inputPassword, callback) {
	bcrypt.compare(inputPassword, this.password, function(err, isMatch) {
		if (err) {
			return callback(err);
		}
		callback(null, isMatch);
	});
};

userSchema.methods.toJSON = function() {
	var obj = this.toObject();
 	delete obj.password;
 	return obj;
}

//Export model
module.exports = mongoose.model('User', userSchema);
